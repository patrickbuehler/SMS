package edu.yale.cpsc112_assignment3;

import java.util.Random;

public class CPSC112_Assignment3 {

  public static String mySecret = "";
  public static boolean DEBUG = true;
  public static Random r = new Random();
  public static int one, two, three, four;
  public static int placeCount = 0; 
  public static int totalCount = 0;
  public static boolean tryToLie = true; //CHECK SCOPE
  public static int exceptions = 3;
  public static int max = 0;

  public static void main(String[] args) {
    makeMySecret();
    isGameOver("1234");
    isGameOver("4321");
    isGameOver("2567");
    isGameOver("1432");
  }

  public static void makeMySecret() {
    // Part 1 code goes here (please leave the next few lines at the end of the makeMySecret method)
	one = two = three = four = 0;
	one = generateCheckInt();
	two = generateCheckInt();
	three = generateCheckInt();
	four = generateCheckInt();
	mySecret = ("" + one + two + three + four);
    if (DEBUG)
    {
       System.out.println("Secret: " + mySecret);
    }
  }

  public static boolean isGuessValid(String input) {
    try 
    {
    	int guess = Integer.parseInt(input);
    	if (isLessThanSeven(guess))
    	{
    		if ((guess % 10) == ((guess / 10) % 10) || (guess % 10) == (guess / 100) % 10 || (guess % 10) == (guess / 1000) % 10 || ((guess / 10) % 10) == (guess / 100) % 10 || ((guess / 10) % 10) == (guess / 1000) % 10 || (guess / 100) % 10 == (guess / 1000) % 10)
    		{
    			System.out.println("Input must be a 4-digit number with digits between 1 and 7.");
    			return false;
    		}
    		else 
    		{
	       		placeCount = 0; 
	    	    totalCount = 0;
	    		return true;
    		}
    	}
    	else 
    	{
        	System.out.println("Input must be a 4-digit number with digits between 1 and 7.");
    		return false;
    	}
    }
    // USE OF TRY/CATCH??
    catch (NumberFormatException e) 
    { 
    	System.out.println("Input must be a 4-digit number with digits between 1 and 7.");
    	return false;
    }
  }

  public static boolean isGameOver(String input) {
     if (!isGuessValid(input))
     {
    	 return false;
     }
     else
     {
    	 int guess = Integer.parseInt(input);
    	 int mySecretInteger = Integer.parseInt(mySecret);
    	 //Exception code
    	 if (exceptions == 0 && guess > mySecretInteger)
    	 {
    		 //System.out.println(guess);
    		 System.out.println("You're out of exceptions and you've guessed too high! The secret was" + mySecretInteger + ".");
    		 return true;
    	 }
    	 else if (exceptions == 0 && guess < max)
    	 {
    		 //System.out.println(guess);
    		 System.out.println("Your guess was lower than allowed. You have 0 exceptions remaining.");
    		 return false;
    	 }
    	 
    		 
    	 else if (findPlaceCount(guess) == 4 && findTotalCount(guess) == 4)
    	 {
    		 System.out.println("You won!");
    		 return true;
    	 }
    	 else
    	 {
    		 // EXCEPTIONS
    		 // Check conditions
    		 if (guess > max)
    		 {
    			 max = guess;
    		 }
    		 else if (guess < max)
    		 {
    			 exceptions--;
    			 //System.out.println("Exception guess = " + guess);
    			 System.out.println("Your guess was lower than allowed. You have " + exceptions + " exceptions remaining.");
    		 }
    		 
    		 // LYING
    		 if (tryToLie && r.nextInt(3) == 0)
        	 {
    			System.out.println("Lie");
    			System.out.print("Guess: " + input + ";");	
    			if (r.nextInt(1) == 0)
    			{
    				int rando = r.nextInt(5);
    				while (findPlaceCount(guess) > rando)
    				{
    					rando = r.nextInt(5);
    				}
    				System.out.println(" Result: " + r.nextInt(5) + "," + findPlaceCount(guess));
    			}
    			else 
    			{
    				int rand = r.nextInt(3);
    				while (rand > totalCount)
    				{
    					rand = r.nextInt(3);
    				}
    				System.out.println(" Result: " + findTotalCount(guess) + "," + rand);
    			}
        		tryToLie = false;
        		return false;
        	 }
    		 else
    		 {
    			 tryToLie = true;
	    		 System.out.print("Guess: " + input + ";");	 
		    	 System.out.println(" Result: " + findTotalCount(guess) + "," + findPlaceCount(guess));
			     return false;
	    	 }	    		 
	     }
     }
 }
  
  public static int findPlaceCount(int guess)
  {
	  placeCount = 0;
	  if ((int) (guess / 1000) == one) placeCount++;
 	  if ((int) (guess / 100) % 10 == two) placeCount++;
 	  if ((int) (guess / 10) % 10 == three) placeCount++;
 	  if (guess % 10 == four) placeCount++;
 	  
	  return placeCount;
  }
  
  public static int findTotalCount(int guess)
  {
	  for (int i = 3; i > -1; i--)
	  {
			if (((int) (guess / Math.pow(10, i)) % 10) == one) totalCount++;
			else if (((int) (guess / Math.pow(10, i)) % 10) == two) totalCount++;
			else if (((int) (guess / Math.pow(10, i)) % 10) == three) totalCount++;
			else if (((int) (guess / Math.pow(10, i)) % 10) == four) totalCount++;
	  }
	  return totalCount;
  }
  
  public static boolean isLessThanSeven(int guess)
  {
	  int iteration = 0;
	  for (int i = 0; i < 4; i++)
	  {
		  if (guess % 10 <= 7)
		  {
			  iteration++;
		  }
		  guess = guess / 10;
	  }
	  if (iteration == 4)
	  {
		  return true;
	  }
	  else return false;
  }
    
  public static int generateCheckInt()
  {
	  int secretInt = r.nextInt(7) + 1;	  
	  if (isNotDuplicate(secretInt))
	  {
		  return secretInt;
	  }
	  else
	  {
		  return generateCheckInt();
	  }
  }
  public static boolean isNotDuplicate(int secretInt)
  {
	 if (secretInt == one || secretInt == two || secretInt == three || secretInt == four) 
	 {
		 return false;
	 }
	 else return true;
  }
}
